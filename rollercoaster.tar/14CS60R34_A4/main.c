#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>

#include "roller-coster.h"

int main(int argc, char const *argv[]) {
  short choice;
  int i = 0, j;
  long sum;
  char line[1024];

  N = atoi(argv[1]);
  T = atoi(argv[2]);
  s = atoi(argv[3]);
  t = atoi(argv[4]);
  p = atof(argv[5]);
  FILE *fp = fopen(argv[6], "rt");

  while(fscanf(fp, "%1024[^\n]%*c", line) != EOF) {
    emotions[i] = (char *) calloc(strlen(line) + 1, 1);
    strcpy(emotions[i++], line);
  }
  no_of_emotions = i;

  int unused = system("rm -rf PID && mkdir -p PID");

  // Allocating shared memory
  car_mode_shm_id = shmget(1, 1, IPC_CREAT | 0666);
  tourist_queue_shm_id = shmget(2, TOURIST_QUEUE_TABLE_SIZE * sizeof(TouristQueueStatusTable), IPC_CREAT | 0666);
  tourist_queue_front_shm_id = shmget(3, sizeof(int), IPC_CREAT | 0666);
  tourist_queue_rear_shm_id = shmget(4, sizeof(int), IPC_CREAT | 0666);
  tourist_status_shm_id = shmget(5, TOURIST_STATUS_TABLE_SIZE * sizeof(TouristStatusTable), IPC_CREAT | 0666);
  tourist_status_index_shm_id = shmget(6, sizeof(int), IPC_CREAT | 0666);
  car_table_shm_id = shmget(7, N * sizeof(CarTable), IPC_CREAT | 0666);
  tourist_arrival_pid_shm_id = shmget(8, sizeof(pid_t), IPC_CREAT | 0666);
  car_load_pid_shm_id = shmget(9, sizeof(pid_t), IPC_CREAT | 0666);
  car_unload_pid_shm_id = shmget(10, sizeof(pid_t), IPC_CREAT | 0666);

  // Attaching shared memory
  CarMode *car_mode = (CarMode *) shmat(car_mode_shm_id, NULL, 0);
  TouristQueueStatusTable *tourist_queue = (TouristQueueStatusTable *) shmat(tourist_queue_shm_id, NULL, 0);
  int *tourist_queue_front = (int *) shmat(tourist_queue_front_shm_id, NULL, 0),
      *tourist_queue_rear = (int *) shmat(tourist_queue_rear_shm_id, NULL, 0);
  TouristStatusTable *tourist_status = (TouristStatusTable *) shmat(tourist_status_shm_id, NULL, 0);
  int *tourist_status_index = (int *) shmat(tourist_status_index_shm_id, NULL, 0);
  CarTable *car_table = (CarTable *) shmat(car_table_shm_id, NULL, 0);
  pid_t *tourist_arrival_pid = (pid_t *) shmat(tourist_arrival_pid_shm_id, NULL, 0),
        *car_load_pid = (pid_t *) shmat(car_load_pid_shm_id, NULL, 0),
        *car_unload_pid = (pid_t *) shmat(car_unload_pid_shm_id, NULL, 0);

  // Creating the semaphores
  sem_t *car_mode_sem = sem_open(CAR_MODE_SEM, O_CREAT, 0644, 1),
        *tourist_queue_sem = sem_open(TOURIST_QUEUE_SEM, O_CREAT, 0644, 1),
        *tourist_status_sem = sem_open(TOURIST_STATUS_SEM, O_CREAT, 0644, 1),
        *car_table_sem = sem_open(CAR_TABLE_SEM, O_CREAT, 0644, 1),
        *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, O_CREAT, 0644, N);

  // Initializing
  *tourist_queue_front = *tourist_queue_rear = *tourist_status_index = 0;
  *car_mode = READY;
  memset(tourist_queue, 0, TOURIST_QUEUE_TABLE_SIZE * sizeof(TouristQueueStatusTable));
  memset(tourist_status, 0, TOURIST_STATUS_TABLE_SIZE * sizeof(TouristStatusTable));
  memset(car_table, 0, N * sizeof(CarTable));

  srand(time(NULL));

  pid_t child = fork();
  if(!child)
    tourist_arrival();
  *tourist_arrival_pid = child;
  child = fork();
  if(!child)
    car_load();
  *car_load_pid = child;
  child = fork();
  if(!child)
    car_unload();
  *car_unload_pid = child;

  signal(SIGINT, SIG_IGN);
  while(true) {
    printf("Menu:\n    \
1. Display Tourist Queue Status\n    \
2. Display Tourist Status\n    \
3. Display Car Status\n    \
4. Exit\n\n");
    #ifndef DEBUG
    printf("Your Input: ");
    #endif
    unused = scanf("%hd", &choice);
    switch(choice) {
      case 1:
        printf("\n\t    Tourist Queue Status\n----------------------------------------------");
        if(*tourist_queue_front == *tourist_queue_rear)
          printf("\nThere's no tourist in the Tourist Queue\n");
        else if(*tourist_queue_front < *tourist_queue_rear) {
          printf("\nPOS\t\tPID\t\tARRIVAL TIME\n");
          printf("----------------------------------------------\n");
          for(i = *tourist_queue_front + 1; i <= *tourist_queue_rear; i++)
            printf("%d\t\t%d\t\t%ld\n", i - *tourist_queue_front, tourist_queue[i].pid, tourist_queue[i].arrival_time);
        }
        else {
          printf("\nPOS\t\tPID\t\tARRIVAL TIME\n");
          printf("----------------------------------------------\n");
          for(i = *tourist_queue_front + 1; i < TOURIST_QUEUE_TABLE_SIZE; i++)
            printf("%d\t\t%d\t\t%ld\n", i - *tourist_queue_front, tourist_queue[i].pid, tourist_queue[i].arrival_time);
          for(j = 0; j <= *tourist_queue_rear; j++)
            printf("%d\t\t%d\t\t%ld\n", i + j, tourist_queue[j].pid, tourist_queue[j].arrival_time);
        }
        putchar('\n');
        break;
      case 2:
        printf("\n\t\t\tTourist Status\n--------------------------------------------------------------------");
        printf("\nPID\tARRIVAL TIME\tSTART TIME\tEND TIME\tWAITING TIME\n");
        printf("--------------------------------------------------------------------\n");
        for(i = 0; i < *tourist_status_index; i++)
          printf("%d\t%ld\t%ld\t%ld\t%ld\n", tourist_status[i].pid, tourist_status[i].arrival_time, tourist_status[i].start_time, tourist_status[i].end_time, tourist_status[i].waiting_time);
        putchar('\n');
        break;
      case 3:
        if(*car_mode != RUNNING)
          printf("\nThe car is not running at the moment\n\n");
        else {
          printf("\n\t\t\tCar Status\n--------------------------------------------------------------------");
          printf("\nPID\t\tARRIVAL TIME\t\tSTART TIME\n");
          printf("--------------------------------------------------------------------\n");
          for(i = 0; i < N; i++)
            printf("%d\t\t%ld\t\t%ld\n", car_table[i].pid, car_table[i].arrival_time, car_table[i].start_time);
          putchar('\n');
        }
        break;
      case 4:
        printf("\t\t---- Exiting ----\n\n");
        #ifdef DEBUG
        printf("    =XX= Tourist Arrival process with pid = %d is TERMINATED\n", *tourist_arrival_pid);
        printf("    =XX= Car Load process with pid = %d is TERMINATED\n", *car_load_pid);
        printf("    =XX= Car Unload process with pid = %d is TERMINATED\n", *car_unload_pid);
        #endif
        kill(*tourist_arrival_pid, SIGINT);
        kill(*car_load_pid, SIGINT);
        kill(*car_unload_pid, SIGINT);
        if(*car_mode == RUNNING) {
          for(i = 0; i < N; i++) {
            #ifdef DEBUG
            printf("    =XX= Tourist process in car with pid = %d is TERMINATED\n", car_table[i].pid);
            #endif
            kill(car_table[i].pid, SIGUSR1);
          }
        }
        if(*tourist_queue_front < *tourist_queue_rear) {
          for(i = *tourist_queue_front + 1; i <= *tourist_queue_rear; i++) {
            #ifdef DEBUG
            printf("    =XX= Tourist process in queue with pid = %d is TERMINATED\n", tourist_queue[i].pid);
            #endif
            kill(tourist_queue[i].pid, SIGUSR1);
          }
        } else if(*tourist_queue_front > *tourist_queue_rear) {
          for(i = *tourist_queue_front + 1; i < TOURIST_QUEUE_TABLE_SIZE; i++) {
            #ifdef DEBUG
            printf("    =XX= Tourist process in queue with pid = %d is TERMINATED\n", tourist_queue[i].pid);
            #endif
            kill(tourist_queue[i].pid, SIGUSR1);
          }
          for(j = 0; j <= *tourist_queue_rear; j++) {
            #ifdef DEBUG
            printf("    =XX= Tourist process in queue with pid = %d is TERMINATED\n", tourist_queue[j].pid);
            #endif
            kill(tourist_queue[j].pid, SIGUSR1);
          }
        }
        sleep(1);
        sum = 0;
        printf("\n\t\t  Waiting Time for Served Tourists\n--------------------------------------------------------------------");
        printf("\nPID\t\t\t\tWAITING TIME\n");
        printf("--------------------------------------------------------------------\n");
        for(i = 0; i < *tourist_status_index; i++) {
          sum += tourist_status[i].waiting_time;
          printf("%d\t\t\t\t%ld\n", tourist_status[i].pid, tourist_status[i].waiting_time);
        }
        printf("\n\t\tAverage Waiting Time is : %lf seconds\n\n", sum * 1.0 / i);
        sem_unlink(CAR_MODE_SEM);
        sem_unlink(TOURIST_QUEUE_SEM);
        sem_unlink(TOURIST_STATUS_SEM);
        sem_unlink(CAR_TABLE_SEM);
        sem_unlink(FINAL_EMOTION_SEM);
        shmctl(car_mode_shm_id, IPC_RMID, NULL);
        shmctl(tourist_queue_shm_id, IPC_RMID, NULL);
        shmctl(tourist_queue_front_shm_id, IPC_RMID, NULL);
        shmctl(tourist_queue_rear_shm_id, IPC_RMID, NULL);
        shmctl(tourist_status_shm_id, IPC_RMID, NULL);
        shmctl(tourist_status_index_shm_id, IPC_RMID, NULL);
        shmctl(car_table_shm_id, IPC_RMID, NULL);
        shmctl(tourist_arrival_pid_shm_id, IPC_RMID, NULL);
        shmctl(car_load_pid_shm_id, IPC_RMID, NULL);
        shmctl(car_unload_pid_shm_id, IPC_RMID, NULL);
        exit(0);
      default:
        break;
    }
  }
  return 0;
}
