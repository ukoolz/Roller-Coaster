#include <stdlib.h>

#define TOURIST_QUEUE_TABLE_SIZE 1000
#define TOURIST_STATUS_TABLE_SIZE 1000

#define CAR_MODE_SEM "/car_mode_sem"
#define TOURIST_QUEUE_SEM "/tourist_queue_sem"
#define TOURIST_STATUS_SEM "/tourist_status_sem"
#define CAR_TABLE_SEM "/car_table_sem"
#define FINAL_EMOTION_SEM "/final_emotion_sem"

#define DEBUG

void tourist_arrival();
void car_load();
void car_unload();

typedef enum {
  READY,
  WAITING,
  RUNNING
} CarMode;

typedef struct {
  pid_t pid;
  long arrival_time;
} TouristQueueStatusTable;

typedef struct {
  pid_t pid;
  long arrival_time, start_time, end_time, waiting_time;
} TouristStatusTable;

typedef struct {
  pid_t pid;
  long arrival_time, start_time;
} CarTable;

int N,
    T,
    s,
    t,
    no_of_emotions;

float p;

char *emotions[100];

int car_mode_shm_id,
    tourist_queue_shm_id,
    tourist_queue_front_shm_id,
    tourist_queue_rear_shm_id,
    tourist_status_shm_id,
    tourist_status_index_shm_id,
    car_table_shm_id,
    tourist_arrival_pid_shm_id,
    car_load_pid_shm_id,
    car_unload_pid_shm_id;