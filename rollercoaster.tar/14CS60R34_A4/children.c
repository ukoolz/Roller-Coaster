#include <stdio.h>
#include <stdbool.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>

#include "roller-coster.h"

char file_name[20];
FILE *fp;

void unblock() {return;}

int random_in_range(int min, int max) {
  int r,
      range = max - min,
      buckets = RAND_MAX / range,
      limit = buckets * range;
  do {
    r = rand();
  } while (r >= limit);
  return min + (r / buckets);
}

void terminate_tourist() {
  #ifdef DEBUG
  printf("    =XX= Tourist with pid = %d is TERMINATED\n", getpid());
  #endif
  exit(0);
}

void terminate() {exit(0);}

void say_final_emotion() {
  sem_t *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, 0);
  #ifdef DEBUG
  printf("    ==== Tourist with pid = %d is saying FINAL emotion\n", getpid());
  #endif
  fp = fopen(file_name, "at");
  fprintf(fp, "Final Emotion : %s\n", emotions[rand() % no_of_emotions]);
  fclose(fp);
  sem_post(final_emotion_sem);
  sem_close(final_emotion_sem);
  return;
}

void tourist() {
  CarMode *car_mode = (CarMode *) shmat(car_mode_shm_id, NULL, 0);
  TouristQueueStatusTable *tourist_queue = (TouristQueueStatusTable *) shmat(tourist_queue_shm_id, NULL, 0);
  int *tourist_queue_front = (int *) shmat(tourist_queue_front_shm_id, NULL, 0),
      *tourist_queue_rear = (int *) shmat(tourist_queue_rear_shm_id, NULL, 0);
  TouristStatusTable *tourist_status = (TouristStatusTable *) shmat(tourist_status_shm_id, NULL, 0);
  int *tourist_status_index = (int *) shmat(tourist_status_index_shm_id, NULL, 0);
  CarTable *car_table = (CarTable *) shmat(car_table_shm_id, NULL, 0);
  pid_t *tourist_arrival_pid = (pid_t *) shmat(tourist_arrival_pid_shm_id, NULL, 0),
        *car_load_pid = (pid_t *) shmat(car_load_pid_shm_id, NULL, 0),
        *car_unload_pid = (pid_t *) shmat(car_unload_pid_shm_id, NULL, 0);

  sem_t *car_mode_sem = sem_open(CAR_MODE_SEM, 0),
        *tourist_queue_sem = sem_open(TOURIST_QUEUE_SEM, 0),
        *tourist_status_sem = sem_open(TOURIST_STATUS_SEM, 0),
        *car_table_sem = sem_open(CAR_TABLE_SEM, 0),
        *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, 0);

  sprintf(file_name, "PID/%d.txt", getpid());

  signal(SIGCONT, unblock);
  signal(SIGUSR1, terminate_tourist);
  signal(SIGUSR2, say_final_emotion);
  while(true) {
    #ifdef DEBUG
    printf("    ==== Tourist with pid = %d is saying INITIAL emotion\n", getpid());
    #endif
    fp = fopen(file_name, "at");
    fprintf(fp, "Initial Emotion : %s\n", emotions[rand() % no_of_emotions]);
    fclose(fp);
    sem_wait(final_emotion_sem);
    pause();
    pause();
  }
}

void tourist_arrival() {
  CarMode *car_mode = (CarMode *) shmat(car_mode_shm_id, NULL, 0);
  TouristQueueStatusTable *tourist_queue = (TouristQueueStatusTable *) shmat(tourist_queue_shm_id, NULL, 0);
  int *tourist_queue_front = (int *) shmat(tourist_queue_front_shm_id, NULL, 0),
      *tourist_queue_rear = (int *) shmat(tourist_queue_rear_shm_id, NULL, 0);
  TouristStatusTable *tourist_status = (TouristStatusTable *) shmat(tourist_status_shm_id, NULL, 0);
  int *tourist_status_index = (int *) shmat(tourist_status_index_shm_id, NULL, 0);
  CarTable *car_table = (CarTable *) shmat(car_table_shm_id, NULL, 0);
  pid_t *tourist_arrival_pid = (pid_t *) shmat(tourist_arrival_pid_shm_id, NULL, 0),
        *car_load_pid = (pid_t *) shmat(car_load_pid_shm_id, NULL, 0),
        *car_unload_pid = (pid_t *) shmat(car_unload_pid_shm_id, NULL, 0);

  sem_t *car_mode_sem = sem_open(CAR_MODE_SEM, 0),
        *tourist_queue_sem = sem_open(TOURIST_QUEUE_SEM, 0),
        *tourist_status_sem = sem_open(TOURIST_STATUS_SEM, 0),
        *car_table_sem = sem_open(CAR_TABLE_SEM, 0),
        *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, 0);

  signal(SIGCONT, unblock);
  signal(SIGINT, terminate);
  while(true) {
    int sleep_time = random_in_range(s, t);
    sleep(sleep_time);
    pid_t tourist_pid = fork();
    if(!tourist_pid)
      tourist();
    kill(tourist_pid, SIGSTOP);
    #ifdef DEBUG
    printf("New tourist with pid = %d is created after %d seconds\n", tourist_pid, sleep_time);
    #endif
    if((*tourist_queue_rear + 1) % TOURIST_QUEUE_TABLE_SIZE == *tourist_queue_front) {
      #ifdef DEBUG
      printf("Tourist Queue Status Table is FULL ...\n");
      #endif
    } else {
      sem_wait(tourist_queue_sem);
      *tourist_queue_rear += 1;
      tourist_queue[*tourist_queue_rear].pid = tourist_pid;
      tourist_queue[*tourist_queue_rear].arrival_time = (long) time(NULL);
      sem_post(tourist_queue_sem);
    }
    if(*car_mode == READY)
      kill(*car_load_pid, SIGCONT);
  }
}

void car_load() {
  CarMode *car_mode = (CarMode *) shmat(car_mode_shm_id, NULL, 0);
  TouristQueueStatusTable *tourist_queue = (TouristQueueStatusTable *) shmat(tourist_queue_shm_id, NULL, 0);
  int *tourist_queue_front = (int *) shmat(tourist_queue_front_shm_id, NULL, 0),
      *tourist_queue_rear = (int *) shmat(tourist_queue_rear_shm_id, NULL, 0);
  TouristStatusTable *tourist_status = (TouristStatusTable *) shmat(tourist_status_shm_id, NULL, 0);
  int *tourist_status_index = (int *) shmat(tourist_status_index_shm_id, NULL, 0);
  CarTable *car_table = (CarTable *) shmat(car_table_shm_id, NULL, 0);
  pid_t *tourist_arrival_pid = (pid_t *) shmat(tourist_arrival_pid_shm_id, NULL, 0),
        *car_load_pid = (pid_t *) shmat(car_load_pid_shm_id, NULL, 0),
        *car_unload_pid = (pid_t *) shmat(car_unload_pid_shm_id, NULL, 0);

  sem_t *car_mode_sem = sem_open(CAR_MODE_SEM, 0),
        *tourist_queue_sem = sem_open(TOURIST_QUEUE_SEM, 0),
        *tourist_status_sem = sem_open(TOURIST_STATUS_SEM, 0),
        *car_table_sem = sem_open(CAR_TABLE_SEM, 0),
        *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, 0);

  signal(SIGCONT, unblock);
  signal(SIGINT, terminate);
  int i;
  do {
    pause();
    int people_in_queue = (*tourist_queue_rear >= *tourist_queue_front) ? *tourist_queue_rear - *tourist_queue_front : TOURIST_QUEUE_TABLE_SIZE - *tourist_queue_front + *tourist_queue_rear;
    if(people_in_queue < N)
      continue;
    else {
      long start_time = (long) time(NULL);
      #ifdef DEBUG
      printf("    ____ Joy Ride STARTS ____\n");
      #endif
      for (i = 0; i < N; ++i) {
        if(*tourist_queue_front == *tourist_queue_rear) {
          #ifdef DEBUG
          printf("Tourist Queue Status Table is EMPTY ...\n");
          #endif
          continue;
        }
        sem_wait(tourist_queue_sem);
        *tourist_queue_front = (*tourist_queue_front + 1) % TOURIST_QUEUE_TABLE_SIZE;
        sem_post(tourist_queue_sem);
        sem_wait(car_table_sem);
        car_table[i].pid = tourist_queue[*tourist_queue_front].pid;
        car_table[i].start_time = start_time;
        car_table[i].arrival_time = tourist_queue[*tourist_queue_front].arrival_time;
        sem_post(car_table_sem);
        kill(car_table[i].pid, SIGCONT);
      }
      sem_wait(car_mode_sem);
      *car_mode = RUNNING;
      sem_post(car_mode_sem);
      sleep(T);
      #ifdef DEBUG
      printf("    ____ Joy Ride ENDS ____\n");
      #endif
      kill(*car_unload_pid, SIGCONT);
      sem_wait(car_mode_sem);
      *car_mode = WAITING;
      sem_post(car_mode_sem);
    }
  } while(true);
}

void car_unload() {
  CarMode *car_mode = (CarMode *) shmat(car_mode_shm_id, NULL, 0);
  TouristQueueStatusTable *tourist_queue = (TouristQueueStatusTable *) shmat(tourist_queue_shm_id, NULL, 0);
  int *tourist_queue_front = (int *) shmat(tourist_queue_front_shm_id, NULL, 0),
      *tourist_queue_rear = (int *) shmat(tourist_queue_rear_shm_id, NULL, 0);
  TouristStatusTable *tourist_status = (TouristStatusTable *) shmat(tourist_status_shm_id, NULL, 0);
  int *tourist_status_index = (int *) shmat(tourist_status_index_shm_id, NULL, 0);
  CarTable *car_table = (CarTable *) shmat(car_table_shm_id, NULL, 0);
  pid_t *tourist_arrival_pid = (pid_t *) shmat(tourist_arrival_pid_shm_id, NULL, 0),
        *car_load_pid = (pid_t *) shmat(car_load_pid_shm_id, NULL, 0),
        *car_unload_pid = (pid_t *) shmat(car_unload_pid_shm_id, NULL, 0);

  sem_t *car_mode_sem = sem_open(CAR_MODE_SEM, 0),
        *tourist_queue_sem = sem_open(TOURIST_QUEUE_SEM, 0),
        *tourist_status_sem = sem_open(TOURIST_STATUS_SEM, 0),
        *car_table_sem = sem_open(CAR_TABLE_SEM, 0),
        *final_emotion_sem = sem_open(FINAL_EMOTION_SEM, 0);

  signal(SIGCONT, unblock);
  signal(SIGINT, terminate);
  int i, k = (p * N) + 0.5;
  int min = k >= N-k ? N-k : k;
  CarTable lucky_tourists[k], unlucky_tourists[N-k];
  do {
    pause();
    long end_time = (long) time(NULL);
    for (i = 0; i < N; i++) {
      if (i < k)
        lucky_tourists[i].pid = car_table[i].pid;
      else
        unlucky_tourists[i-k].pid = car_table[i].pid;
    }
    sem_wait(tourist_status_sem);
    for (i = 0; i < N; ++i) {
      kill(car_table[i].pid, SIGUSR2);
      tourist_status[*tourist_status_index + i].pid = car_table[i].pid;
      tourist_status[*tourist_status_index + i].arrival_time = car_table[i].arrival_time;
      tourist_status[*tourist_status_index + i].start_time = car_table[i].start_time;
      tourist_status[*tourist_status_index + i].end_time = end_time;
      tourist_status[*tourist_status_index + i].waiting_time = car_table[i].start_time - car_table[i].arrival_time;
    }
    *tourist_status_index += N;
    sem_post(tourist_status_sem);
    if(min) {
      for (i = 0; i < N; ++i) {
        int j = rand() % min;
        pid_t tmp = unlucky_tourists[j].pid;
        unlucky_tourists[j].pid = lucky_tourists[j].pid;
        lucky_tourists[j].pid = tmp;
      }
    }
    int value;
    do {
      sleep(1);
      sem_getvalue(final_emotion_sem , &value);
    } while (value < N);

    sem_wait(tourist_queue_sem);
    for (i = 0; i < k; i++) {
      #ifdef DEBUG
      printf("    ++++ Tourist with pid = %d is selected for another round\n", lucky_tourists[i].pid);
      #endif
      if((*tourist_queue_rear + 1) % TOURIST_QUEUE_TABLE_SIZE == *tourist_queue_front) {
        #ifdef DEBUG
        printf("Tourist Queue Status Table is FULL ...\n");
        #endif
        continue;
      } else {
        *tourist_queue_rear += 1;
        tourist_queue[*tourist_queue_rear].pid = lucky_tourists[i].pid;
        tourist_queue[*tourist_queue_rear].arrival_time = (long) time(NULL);
      }
    }
    sem_post(tourist_queue_sem);
    for (i = 0; i < N-k; i++) {
      #ifdef DEBUG
      printf("    ---- The buck stops here for tourist with pid = %d\n", unlucky_tourists[i].pid);
      #endif
      kill(unlucky_tourists[i].pid, SIGUSR1);
    }
    sem_wait(car_mode_sem);
    *car_mode = READY;
    sem_post(car_mode_sem);
  } while(true);
}